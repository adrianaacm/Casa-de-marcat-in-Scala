package shop
import database.Table
import database.queryT
import database.Field
import database.Not
import database.PP_SQL_Table_Filter
import database.PP_SQL_Table_Update
class Commands(productsTable: Table) {
    // 3.1.1
    def START_SHOPPING() : Table = ???
    // 3.1.2
    def ADD_PRODUCT(shopList: Table, barcode: String, quantity: Int): Table = ???
    // 3.1.3
    def DELETE_PRODUCT(t: Table, name: String): Table = ???
    // 3.1.4
    def EDIT_QUANTITY(t: Table, name: String, newQuantity: Int): Table = ???
}
