package database 

import scala.annotation.tailrec

type Row = Map[String, String]
type Tabular = List[Row]

object Table {
  // 2.1.1
  def apply(name: String, s: String): Table = ???
}

case class Table (tableName: String, tableData: Tabular) {

  def header: List[String] = ???
  def data: Tabular = ???
  def name: String = ???

  // 2.1.2
  override def toString: String = ???

  // 2.1.3
  def insert(row: Row): Table = ???

  // 2.1.4
  def delete(row: Row): Table = ???

  // 2.1.5
  def sort(column: String, ascending: Boolean = true): Table = ???

  // 2.1.6
  def select(columns: List[String]): Table = ???
}

extension (table: Table) {
  def apply(i: Int): Row = {
    table.data(i)
  }
}
